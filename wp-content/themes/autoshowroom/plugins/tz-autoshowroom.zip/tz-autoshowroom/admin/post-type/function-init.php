<?php

$dir_pt = dirname( __FILE__ );
require_once $dir_pt . '/agency-post-type.php';
?>