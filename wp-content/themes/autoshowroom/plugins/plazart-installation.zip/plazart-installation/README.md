# Plazart Installation - Wordpress Plugin

*** Changelogs ***

11/09/2020 - 1.0.3
	
	- Fix error import max mega menu v2.9.0.2

17/04/2020 - 1.0.2
	
	- Added reactivate button.
	- Added allway check license by ajax
	- Added notice when domain don't activate.
	- Check license and download package by domain.
	- Changed theme name to theme title on head.