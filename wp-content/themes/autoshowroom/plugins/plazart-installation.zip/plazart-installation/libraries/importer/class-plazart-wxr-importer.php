<?php

defined( 'ABSPATH' ) || exit;

if( class_exists( 'WXR_Importer') ) {
class Plzinst_WXR_Importer extends WXR_Importer {}
}
