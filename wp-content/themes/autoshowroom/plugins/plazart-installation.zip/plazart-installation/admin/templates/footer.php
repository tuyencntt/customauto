<?php
/**
 * Base layout for all admin pages
 */
?>
<div class="plzinst-footer">
    <?php echo __("Power by plazart framework", $this -> text_domain); ?>
</div>