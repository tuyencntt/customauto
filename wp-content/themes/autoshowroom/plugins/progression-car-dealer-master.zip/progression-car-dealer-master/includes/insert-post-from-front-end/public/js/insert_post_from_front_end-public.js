(function ($) {
    'use strict';
    /*
     * Disables all models that do not fit the selected make
     */



})(jQuery);
